import { Navigation } from '@/sections/Navigation';
import { Hero } from '@/sections/Hero';
import { Services } from '@/sections/Services';
import { CaseStudies } from '@/sections/CaseStudies';
import { Process } from '@/sections/Process';
import { CTA } from '@/sections/CTA';
import { Footer } from '@/sections/Footer';

function App() {
  return (
    <div className="min-h-screen bg-black">
      <Navigation />
      <Hero />
      <div id="services">
        <Services />
      </div>
      <div id="case-studies">
        <CaseStudies />
      </div>
      <div id="process">
        <Process />
      </div>
      <div id="contact">
        <CTA />
      </div>
      <Footer />
    </div>
  );
}

export default App;
