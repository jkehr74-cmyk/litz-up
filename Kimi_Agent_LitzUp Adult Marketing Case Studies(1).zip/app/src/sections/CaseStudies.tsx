import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Users, DollarSign } from 'lucide-react';

const caseStudies = [
  {
    name: 'Mia',
    platform: 'OnlyFans',
    handle: '@miadreams',
    image: '/creator-mia.jpg',
    strategy: 'Reddit & X Traffic Funneling',
    tagline: 'From invisible to irresistible — turning casual browsers into paid subscribers',
    problem: 'Mia had 12K Twitter followers but only 89 paid subscribers. Her content was great, but she had no system to convert followers into buyers.',
    solution: 'We built a Reddit-to-Twitter-to-OnlyFans funnel with daily posting schedules, teaser clips, and strategic bio links. Implemented A/B tested landing pages.',
    before: { subs: '89', revenue: '$1,200/mo', conversion: '0.7%' },
    after: { subs: '1,340', revenue: '$18,500/mo', conversion: '4.2%' },
    timeframe: '8 weeks',
    metrics: [
      { label: 'Subscriber Growth', value: '+1,405%', icon: Users },
      { label: 'Monthly Revenue', value: '+1,442%', icon: DollarSign },
      { label: 'Conversion Rate', value: '6x', icon: TrendingUp },
    ],
  },
  {
    name: 'Sophia',
    platform: 'Fansly',
    handle: '@sophiarose',
    image: '/creator-sophia.jpg',
    strategy: 'Content Repurposing & Automation',
    tagline: 'One piece of content, five revenue streams — working smarter, not harder',
    problem: 'Sophia was spending 6+ hours daily creating content for one platform. She was burned out and her growth had plateaued at 200 fans.',
    solution: 'We built an automated content repurposing system: long-form videos → TikTok/Reels clips → carousel posts → PPV teasers → story snippets. Scheduled everything.',
    before: { subs: '203', revenue: '$2,800/mo', conversion: 'N/A' },
    after: { subs: '1,890', revenue: '$24,200/mo', conversion: 'N/A' },
    timeframe: '10 weeks',
    metrics: [
      { label: 'Time Saved', value: '25 hrs/wk', icon: TrendingUp },
      { label: 'Fan Growth', value: '+831%', icon: Users },
      { label: 'Monthly Revenue', value: '+764%', icon: DollarSign },
    ],
  },
  {
    name: 'Ava',
    platform: 'Chaturbate',
    handle: '@avawild',
    image: '/creator-ava.jpg',
    strategy: 'Chat Monetization & PPV Upsells',
    tagline: 'From tips and tokens to predictable paydays — every message becomes money',
    problem: 'Ava relied entirely on tips during live shows. Off-camera, her DMs were dead and she had no passive income between streams.',
    solution: 'We created scripted DM flows, PPV video funnels, and VIP fan tiers. Built automated "welcome" and "re-engagement" sequences that sell 24/7.',
    before: { subs: 'N/A', revenue: '$3,100/mo', conversion: 'N/A' },
    after: { subs: 'N/A', revenue: '$16,800/mo', conversion: 'N/A' },
    timeframe: '6 weeks',
    metrics: [
      { label: 'PPV Revenue', value: '+340%', icon: DollarSign },
      { label: 'DM Sales Rate', value: '28%', icon: TrendingUp },
      { label: 'Monthly Revenue', value: '+442%', icon: DollarSign },
    ],
  },
  {
    name: 'Isabella',
    platform: 'Fanvue',
    handle: '@isabellaluxe',
    image: '/creator-isabella.jpg',
    strategy: 'Profile Optimization & Conversion',
    tagline: 'First impressions that convert — turning profile visits into paid subscriptions',
    problem: 'Isabella had high traffic to her Fanvue but a 0.3% conversion rate. Visitors clicked away without subscribing.',
    solution: 'Complete profile overhaul: bio psychology, thumbnail A/B testing, tier restructuring, free preview strategy, and social proof integration.',
    before: { subs: '156', revenue: '$1,900/mo', conversion: '0.3%' },
    after: { subs: '987', revenue: '$12,400/mo', conversion: '2.8%' },
    timeframe: '5 weeks',
    metrics: [
      { label: 'Profile Conversion', value: '9.3x', icon: TrendingUp },
      { label: 'New Subscribers', value: '+533%', icon: Users },
      { label: 'Monthly Revenue', value: '+553%', icon: DollarSign },
    ],
  },
  {
    name: 'Zoe',
    platform: 'Multi-Platform',
    handle: '@zoexoxo',
    image: '/creator-zoe.jpg',
    strategy: 'Fan Retention & PPV Optimization',
    tagline: 'Keeping fans paying longer — turning one-time buyers into loyal monthly spenders',
    problem: 'Zoe was losing 40% of subscribers monthly. Her churn was killing her growth despite bringing in new fans consistently.',
    solution: 'Implemented retention campaigns: personalized re-bill incentives, exclusive content drops, birthday rewards, and "win-back" offers for expired subs.',
    before: { subs: '670', revenue: '$8,200/mo', conversion: 'N/A' },
    after: { subs: '1,240', revenue: '$21,600/mo', conversion: 'N/A' },
    timeframe: '12 weeks',
    metrics: [
      { label: 'Retention Rate', value: '+64%', icon: TrendingUp },
      { label: 'Churn Reduced', value: '-58%', icon: Users },
      { label: 'Monthly Revenue', value: '+163%', icon: DollarSign },
    ],
  },
];

export function CaseStudies() {
  return (
    <section className="relative py-24 md:py-32 bg-black">
      {/* Gold accent line */}
      <div className="absolute top-0 left-0 right-0 h-[2px] gold-gradient-bg" />
      
      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-4">
            Creator Success Stories
          </h2>
          <p className="font-serif italic text-lg text-white/60 max-w-xl mx-auto">
            Real results from creators who trusted LitzUp to scale their business
          </p>
          <div className="w-24 h-[2px] gold-gradient-bg mx-auto mt-6" />
        </div>

        {/* Case Studies */}
        <div className="space-y-12">
          {caseStudies.map((study, index) => (
            <Card 
              key={study.name} 
              className={`border-gold/10 bg-black/60 backdrop-blur-sm overflow-hidden ${
                index % 2 === 1 ? 'md:[direction:rtl]' : ''
              }`}
            >
              <CardContent className="p-0">
                <div className={`grid md:grid-cols-2 gap-0 ${index % 2 === 1 ? 'md:[direction:ltr]' : ''}`}>
                  {/* Image */}
                  <div className="relative h-80 md:h-auto min-h-[400px] overflow-hidden">
                    <img 
                      src={study.image} 
                      alt={study.name}
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                    <div className="absolute bottom-6 left-6 right-6">
                      <Badge className="bg-gold/20 text-gold border-gold/30 mb-2">
                        {study.platform}
                      </Badge>
                      <h3 className="font-serif text-3xl font-bold text-white">
                        {study.name}
                      </h3>
                      <p className="text-white/60 text-sm">{study.handle}</p>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-8 md:p-10 flex flex-col justify-center">
                    <div className="mb-2">
                      <span className="text-gold text-sm font-semibold tracking-wider uppercase">
                        Strategy: {study.strategy}
                      </span>
                    </div>
                    
                    <h4 className="font-serif text-xl md:text-2xl font-bold text-white mb-4 italic">
                      "{study.tagline}"
                    </h4>

                    <div className="space-y-4 mb-6">
                      <div>
                        <p className="text-white/40 text-xs uppercase tracking-wider mb-1">The Problem</p>
                        <p className="text-white/70 text-sm leading-relaxed">{study.problem}</p>
                      </div>
                      <div>
                        <p className="text-white/40 text-xs uppercase tracking-wider mb-1">LitzUp Solution</p>
                        <p className="text-white/70 text-sm leading-relaxed">{study.solution}</p>
                      </div>
                    </div>

                    {/* Before/After */}
                    <div className="grid grid-cols-2 gap-4 mb-6">
                      <div className="bg-white/5 p-4 rounded-sm">
                        <p className="text-white/40 text-xs uppercase tracking-wider mb-2">Before</p>
                        <p className="text-white/60 text-sm">{study.before.revenue}</p>
                        <p className="text-white/60 text-sm">{study.before.subs} subs</p>
                      </div>
                      <div className="bg-gold/10 p-4 rounded-sm border border-gold/20">
                        <p className="text-gold text-xs uppercase tracking-wider mb-2">After {study.timeframe}</p>
                        <p className="text-gold font-bold text-lg">{study.after.revenue}</p>
                        <p className="text-gold text-sm">{study.after.subs} subs</p>
                      </div>
                    </div>

                    {/* Metrics */}
                    <div className="grid grid-cols-3 gap-3">
                      {study.metrics.map((metric) => (
                        <div key={metric.label} className="bg-white/5 p-3 rounded-sm text-center">
                          <metric.icon className="h-4 w-4 text-gold mx-auto mb-1" />
                          <p className="text-gold font-bold text-sm">{metric.value}</p>
                          <p className="text-white/40 text-xs">{metric.label}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
