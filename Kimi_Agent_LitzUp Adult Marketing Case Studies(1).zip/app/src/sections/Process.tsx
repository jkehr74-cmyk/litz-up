import { Card, CardContent } from '@/components/ui/card';
import { BarChart3, Shield, Clock, Target, Zap, Lock } from 'lucide-react';

const steps = [
  {
    number: '01',
    title: 'Audit Your Funnel',
    description: 'We analyze your profile, content flow, and conversion points to find the leaks costing you money.',
    icon: Target,
  },
  {
    number: '02',
    title: 'Install the System',
    description: 'We build your custom traffic, conversion, and retention system tailored to your platform and audience.',
    icon: Zap,
  },
  {
    number: '03',
    title: 'Scale Predictably',
    description: 'With systems running, we optimize weekly using real data — so your revenue grows month after month.',
    icon: BarChart3,
  },
];

const values = [
  {
    title: 'Platform-Smart',
    description: 'We know the rules. No banned accounts, no lost revenue. Every strategy is compliance-first.',
    icon: Shield,
  },
  {
    title: 'Fast Results',
    description: 'Most creators see measurable improvements within 2-4 weeks of implementing our systems.',
    icon: Clock,
  },
  {
    title: 'Discretion Guaranteed',
    description: 'Your privacy is sacred. NDAs on request. White-label systems. Your brand, your control.',
    icon: Lock,
  },
];

export function Process() {
  return (
    <section className="relative py-24 md:py-32 bg-cream">
      <div className="max-w-6xl mx-auto px-6">
        {/* How It Works */}
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-black mb-4">
            How LitzUp Works
          </h2>
          <p className="font-serif italic text-lg text-black/60 max-w-xl mx-auto">
            A proven system installed in three phases — no guesswork, just growth
          </p>
          <div className="w-24 h-[2px] gold-gradient-bg mx-auto mt-6" />
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-24">
          {steps.map((step) => (
            <Card key={step.number} className="border-gold/15 bg-white shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="flex items-center justify-between mb-6">
                  <step.icon className="h-8 w-8 text-gold" />
                  <span className="font-serif text-4xl font-bold text-gold/20">{step.number}</span>
                </div>
                <h3 className="font-serif text-xl font-bold text-black mb-3">
                  {step.title}
                </h3>
                <p className="text-black/60 leading-relaxed">
                  {step.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Why LitzUp */}
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-black mb-4">
            Why Creators Trust Us
          </h2>
          <div className="w-24 h-[2px] gold-gradient-bg mx-auto mt-6" />
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {values.map((value) => (
            <Card key={value.title} className="border-gold/15 bg-white shadow-md hover:shadow-lg transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="w-14 h-14 gold-gradient-bg rounded-full flex items-center justify-center mx-auto mb-5">
                  <value.icon className="h-6 w-6 text-black" />
                </div>
                <h3 className="font-serif text-xl font-bold text-black mb-3">
                  {value.title}
                </h3>
                <p className="text-black/60 leading-relaxed">
                  {value.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
