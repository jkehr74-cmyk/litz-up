import { Flame } from 'lucide-react';

export function Footer() {
  return (
    <footer className="relative bg-black pt-16 pb-8">
      {/* Gold accent line */}
      <div className="absolute top-0 left-0 right-0 h-[2px] gold-gradient-bg" />
      
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex flex-col items-center text-center mb-10">
          <img 
            src="/logo_header.png" 
            alt="LitzUp LLC" 
            className="h-20 w-auto mb-4 opacity-80"
          />
          <h3 className="font-serif text-xl text-white/80 mb-2">
            LitzUp LLC | Revenue Growth for Adult Content Creators
          </h3>
          <div className="flex items-center gap-4 text-gold text-sm mt-2">
            <span className="flex items-center gap-1">
              <Flame className="h-3 w-3" />
              Subscriber Growth
            </span>
            <span className="text-white/20">•</span>
            <span className="flex items-center gap-1">
              <Flame className="h-3 w-3" />
              PPV Optimization
            </span>
            <span className="text-white/20">•</span>
            <span className="flex items-center gap-1">
              <Flame className="h-3 w-3" />
              Retention Systems
            </span>
          </div>
        </div>

        <div className="border-t border-gold/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-white/30 text-sm">
            © 2025 LitzUp LLC. All rights reserved.
          </p>
          <div className="flex items-center gap-6 text-sm">
            <a href="#" className="text-white/40 hover:text-gold transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-white/40 hover:text-gold transition-colors">
              Terms of Service
            </a>
            <a 
              href="mailto:info@litz-up.com" 
              className="text-gold hover:text-gold-light transition-colors font-medium"
            >
              Book a Call: info@litz-up.com
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
