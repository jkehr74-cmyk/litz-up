import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Check, Star, Zap } from 'lucide-react';

const auditFeatures = [
  'Profile & Bio Optimization',
  'Content & Funnel Review',
  'Subscriber Conversion Analysis',
  'PPV Upsell Suggestions',
  '"3 Fast Revenue Fixes within 48 Hours"',
];

const growthFeatures = [
  'Traffic Growth Strategy',
  'X / Reddit Funneling',
  'DM & PPV Sales Scripts',
  'Fan Retention Campaigns',
  'Weekly Performance Reports',
];

export function Services() {
  return (
    <section className="relative py-24 md:py-32 bg-cream">
      <div className="max-w-6xl mx-auto px-6">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-black mb-4">
            How We Scale Your Revenue
          </h2>
          <p className="font-serif italic text-lg text-black/60 max-w-xl mx-auto">
            Two ways to work with us. Start with an audit or go all-in with our growth system.
          </p>
          <div className="w-24 h-[2px] gold-gradient-bg mx-auto mt-6" />
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Creator Growth Audit */}
          <Card className="relative border-gold/20 bg-white shadow-lg hover:shadow-xl transition-shadow overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1 gold-gradient-bg" />
            <CardContent className="p-8 md:p-10">
              <div className="flex items-center gap-2 mb-6">
                <Zap className="h-5 w-5 text-gold" />
                <span className="text-sm font-semibold text-gold-dark tracking-wider uppercase">
                  Quick Start
                </span>
              </div>
              
              <h3 className="font-serif text-2xl md:text-3xl font-bold text-black mb-2">
                Creator Growth Audit
              </h3>
              
              <div className="flex items-baseline gap-1 mb-8">
                <span className="font-serif text-5xl font-bold text-black">$99</span>
                <span className="text-black/50">one-time</span>
              </div>

              <ul className="space-y-4 mb-8">
                {auditFeatures.map((feature, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <Check className="h-5 w-5 text-gold shrink-0 mt-0.5" />
                    <span className="text-black/80">{feature}</span>
                  </li>
                ))}
              </ul>

              <div className="bg-cream-dark/50 p-4 rounded-sm mb-8 border-l-2 border-gold">
                <p className="font-serif italic text-sm text-black/70">
                  If you don't find at least 2 actionable revenue improvements, you don't pay.
                </p>
              </div>

              <Button 
                className="w-full gold-gradient-bg text-black font-semibold py-6 rounded-sm hover:opacity-90 transition-opacity"
              >
                Get Your Audit
              </Button>
            </CardContent>
          </Card>

          {/* LitzUp Growth System */}
          <Card className="relative border-gold/30 bg-black shadow-2xl hover:shadow-gold/20 transition-all overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1 gold-gradient-bg" />
            <div className="absolute top-4 right-4">
              <div className="bg-gold/20 px-3 py-1 rounded-sm">
                <span className="text-gold text-xs font-semibold tracking-wider uppercase">
                  Most Popular
                </span>
              </div>
            </div>
            <CardContent className="p-8 md:p-10">
              <div className="flex items-center gap-2 mb-6">
                <Star className="h-5 w-5 text-gold" />
                <span className="text-sm font-semibold text-gold tracking-wider uppercase">
                  Full Service
                </span>
              </div>
              
              <h3 className="font-serif text-2xl md:text-3xl font-bold text-white mb-2">
                LitzUp Growth System
              </h3>
              
              <div className="flex items-baseline gap-1 mb-8">
                <span className="font-serif text-5xl font-bold gold-gradient-text">$750–$1,500</span>
                <span className="text-white/50">/month</span>
              </div>

              <ul className="space-y-4 mb-8">
                {growthFeatures.map((feature, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <Check className="h-5 w-5 text-gold shrink-0 mt-0.5" />
                    <span className="text-white/80">{feature}</span>
                  </li>
                ))}
              </ul>

              <div className="bg-white/5 p-4 rounded-sm mb-8 border-l-2 border-gold">
                <p className="font-serif italic text-sm text-white/70">
                  Convert Your Traffic into Recurring Monthly Revenue.
                </p>
              </div>

              <Button 
                className="w-full gold-gradient-bg text-black font-semibold py-6 rounded-sm hover:opacity-90 transition-opacity"
              >
                Apply for Growth System
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
