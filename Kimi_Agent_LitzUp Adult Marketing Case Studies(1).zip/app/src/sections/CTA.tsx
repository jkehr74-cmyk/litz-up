import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Mail, ArrowRight } from 'lucide-react';
import { useState } from 'react';

export function CTA() {
  const [formData, setFormData] = useState({ name: '', email: '', platform: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real implementation, this would send to a backend
    alert('Thanks for reaching out! We\'ll be in touch within 24 hours.');
  };

  return (
    <section className="relative py-24 md:py-32 bg-black">
      {/* Gold accent line */}
      <div className="absolute top-0 left-0 right-0 h-[2px] gold-gradient-bg" />
      
      {/* Background glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(197,160,89,0.06)_0%,_transparent_70%)]" />

      <div className="relative z-10 max-w-4xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-4">
            Ready to Scale Your Revenue?
          </h2>
          <p className="font-serif italic text-lg text-white/60 max-w-xl mx-auto">
            Book a free strategy call or send us a message. We only take on creators we know we can help.
          </p>
          <div className="w-24 h-[2px] gold-gradient-bg mx-auto mt-6" />
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-start">
          {/* Contact Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="text-white/50 text-sm mb-2 block">Creator Name / Handle</label>
              <Input 
                placeholder="@yourhandle"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="bg-white/5 border-gold/20 text-white placeholder:text-white/30 focus:border-gold"
              />
            </div>
            <div>
              <label className="text-white/50 text-sm mb-2 block">Email</label>
              <Input 
                type="email"
                placeholder="you@email.com"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className="bg-white/5 border-gold/20 text-white placeholder:text-white/30 focus:border-gold"
              />
            </div>
            <div>
              <label className="text-white/50 text-sm mb-2 block">Primary Platform</label>
              <Input 
                placeholder="OnlyFans, Fansly, Fanvue, etc."
                value={formData.platform}
                onChange={(e) => setFormData({...formData, platform: e.target.value})}
                className="bg-white/5 border-gold/20 text-white placeholder:text-white/30 focus:border-gold"
              />
            </div>
            <div>
              <label className="text-white/50 text-sm mb-2 block">What are you struggling with?</label>
              <Textarea 
                placeholder="Traffic, conversion, retention, content workflow..."
                value={formData.message}
                onChange={(e) => setFormData({...formData, message: e.target.value})}
                className="bg-white/5 border-gold/20 text-white placeholder:text-white/30 focus:border-gold min-h-[100px]"
              />
            </div>
            <Button 
              type="submit"
              className="w-full gold-gradient-bg text-black font-semibold py-6 rounded-sm hover:opacity-90 transition-opacity group"
            >
              Send Message
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </form>

          {/* Contact Info */}
          <div className="space-y-8">
            <div className="bg-white/5 p-6 rounded-sm border border-gold/10">
              <div className="flex items-center gap-3 mb-3">
                <Mail className="h-5 w-5 text-gold" />
                <span className="text-white font-semibold">Email Us</span>
              </div>
              <p className="text-white/60 text-sm">
                Response within 24 hours
              </p>
              <a 
                href="mailto:info@litz-up.com" 
                className="text-gold hover:text-gold-light transition-colors text-lg font-medium mt-1 block"
              >
                info@litz-up.com
              </a>
            </div>

            <div className="bg-white/5 p-6 rounded-sm border border-gold/10">
              <h3 className="font-serif text-xl font-bold text-white mb-4">
                What happens next?
              </h3>
              <ol className="space-y-3">
                <li className="flex items-start gap-3">
                  <span className="text-gold font-bold">1.</span>
                  <span className="text-white/70 text-sm">We review your platform and current metrics</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-gold font-bold">2.</span>
                  <span className="text-white/70 text-sm">We identify your biggest revenue leak in 24 hours</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-gold font-bold">3.</span>
                  <span className="text-white/70 text-sm">We propose a custom growth plan</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-gold font-bold">4.</span>
                  <span className="text-white/70 text-sm">You decide: Audit ($99) or Growth System ($750-$1,500/mo)</span>
                </li>
              </ol>
            </div>

            <div className="gold-gradient-bg p-6 rounded-sm">
              <p className="text-black font-serif italic text-center font-semibold">
                "Limited Client Slots to Maintain Performance Quality"
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
