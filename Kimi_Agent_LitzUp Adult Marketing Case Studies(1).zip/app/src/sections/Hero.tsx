import { Button } from '@/components/ui/button';
import { ArrowRight, Flame } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center bg-black overflow-hidden">
      {/* Gold accent line at top */}
      <div className="absolute top-0 left-0 right-0 h-[2px] gold-gradient-bg" />
      
      {/* Subtle radial glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(197,160,89,0.08)_0%,_transparent_70%)]" />
      
      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        {/* Logo */}
        <div className="mb-10 flex flex-col items-center">
          <img 
            src="/logo_header.png" 
            alt="LitzUp LLC" 
            className="h-28 md:h-36 w-auto mb-4"
          />
        </div>

        {/* Headline */}
        <h1 className="font-serif text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight tracking-tight">
          Turn Your Content into{' '}
          <span className="gold-gradient-text">Predictable</span>{' '}
          Monthly Revenue
        </h1>

        {/* Subtitle */}
        <p className="font-serif italic text-lg md:text-xl text-white/70 mb-10 max-w-2xl mx-auto leading-relaxed">
          Creators we've worked with typically see increases in subscriber conversion & PPV revenue within weeks
        </p>

        {/* Gold banner */}
        <div className="gold-gradient-bg px-8 py-4 rounded-sm mb-12 inline-block">
          <p className="font-serif italic text-black font-semibold text-sm md:text-base tracking-wide">
            Limited Client Slots to Maintain Performance Quality
          </p>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button 
            size="lg"
            className="gold-gradient-bg text-black font-semibold px-8 py-6 text-base rounded-sm hover:opacity-90 transition-opacity group"
          >
            Book a Free Strategy Call
            <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </Button>
          <Button 
            variant="outline" 
            size="lg"
            className="border-gold/40 text-gold hover:bg-gold/10 px-8 py-6 text-base rounded-sm"
          >
            View Case Studies
          </Button>
        </div>

        {/* Trust indicators */}
        <div className="mt-16 flex flex-wrap justify-center gap-8 text-white/50 text-sm">
          <div className="flex items-center gap-2">
            <Flame className="h-4 w-4 text-gold" />
            <span>Subscriber Growth</span>
          </div>
          <div className="flex items-center gap-2">
            <Flame className="h-4 w-4 text-gold" />
            <span>PPV Optimization</span>
          </div>
          <div className="flex items-center gap-2">
            <Flame className="h-4 w-4 text-gold" />
            <span>Retention Systems</span>
          </div>
        </div>
      </div>

      {/* Bottom gold line */}
      <div className="absolute bottom-0 left-0 right-0 h-[2px] gold-gradient-bg" />
    </section>
  );
}
