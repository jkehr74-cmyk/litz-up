import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X } from 'lucide-react';

const navLinks = [
  { label: 'Services', href: '#services' },
  { label: 'Case Studies', href: '#case-studies' },
  { label: 'How It Works', href: '#process' },
  { label: 'Contact', href: '#contact' },
];

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-black/90 backdrop-blur-md border-b border-gold/10' 
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2">
          <img 
            src="/logo_flame.png" 
            alt="LitzUp" 
            className="h-8 w-auto"
          />
          <span className="font-serif text-white font-semibold hidden sm:block">LitzUp LLC</span>
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a 
              key={link.label}
              href={link.href}
              className="text-white/60 hover:text-gold transition-colors text-sm font-medium"
            >
              {link.label}
            </a>
          ))}
          <Button 
            size="sm"
            className="gold-gradient-bg text-black font-semibold rounded-sm hover:opacity-90"
          >
            Book a Call
          </Button>
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-white"
          onClick={() => setIsMobileOpen(!isMobileOpen)}
        >
          {isMobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileOpen && (
        <div className="md:hidden bg-black/95 border-t border-gold/10 px-6 py-6 space-y-4">
          {navLinks.map((link) => (
            <a 
              key={link.label}
              href={link.href}
              onClick={() => setIsMobileOpen(false)}
              className="block text-white/70 hover:text-gold transition-colors text-lg"
            >
              {link.label}
            </a>
          ))}
          <Button 
            className="w-full gold-gradient-bg text-black font-semibold rounded-sm hover:opacity-90 mt-4"
          >
            Book a Call
          </Button>
        </div>
      )}
    </nav>
  );
}
